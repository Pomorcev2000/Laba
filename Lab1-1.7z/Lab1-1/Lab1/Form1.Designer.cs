﻿namespace Lab1
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.TBPhone = new System.Windows.Forms.TextBox();
            this.TBFirstName = new System.Windows.Forms.TextBox();
            this.LPhone = new System.Windows.Forms.Label();
            this.FirstName = new System.Windows.Forms.Label();
            this.NomerButton = new System.Windows.Forms.Button();
            this.FirstNameButton = new System.Windows.Forms.Button();
            this.tbResults = new System.Windows.Forms.TextBox();
            this.Lcount = new System.Windows.Forms.Label();
            this.Delete = new System.Windows.Forms.Button();
            this.Update = new System.Windows.Forms.Button();
            this.Results = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // TBPhone
            // 
            this.TBPhone.Location = new System.Drawing.Point(78, 72);
            this.TBPhone.Name = "TBPhone";
            this.TBPhone.Size = new System.Drawing.Size(100, 20);
            this.TBPhone.TabIndex = 0;
            // 
            // TBFirstName
            // 
            this.TBFirstName.Location = new System.Drawing.Point(270, 72);
            this.TBFirstName.Name = "TBFirstName";
            this.TBFirstName.Size = new System.Drawing.Size(100, 20);
            this.TBFirstName.TabIndex = 1;
            // 
            // LPhone
            // 
            this.LPhone.AutoSize = true;
            this.LPhone.Location = new System.Drawing.Point(75, 26);
            this.LPhone.Name = "LPhone";
            this.LPhone.Size = new System.Drawing.Size(41, 13);
            this.LPhone.TabIndex = 2;
            this.LPhone.Text = "Номер";
            // 
            // FirstName
            // 
            this.FirstName.AutoSize = true;
            this.FirstName.Location = new System.Drawing.Point(341, 26);
            this.FirstName.Name = "FirstName";
            this.FirstName.Size = new System.Drawing.Size(29, 13);
            this.FirstName.TabIndex = 3;
            this.FirstName.Text = "Имя";
            this.FirstName.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // NomerButton
            // 
            this.NomerButton.Location = new System.Drawing.Point(78, 127);
            this.NomerButton.Name = "NomerButton";
            this.NomerButton.Size = new System.Drawing.Size(75, 23);
            this.NomerButton.TabIndex = 4;
            this.NomerButton.Text = "Добавить";
            this.NomerButton.UseVisualStyleBackColor = true;
            this.NomerButton.Click += new System.EventHandler(this.NomerButton_Click);
            // 
            // FirstNameButton
            // 
            this.FirstNameButton.Location = new System.Drawing.Point(295, 127);
            this.FirstNameButton.Name = "FirstNameButton";
            this.FirstNameButton.Size = new System.Drawing.Size(75, 23);
            this.FirstNameButton.TabIndex = 5;
            this.FirstNameButton.Text = "Найти";
            this.FirstNameButton.UseVisualStyleBackColor = true;
            this.FirstNameButton.Click += new System.EventHandler(this.FirstNameButton_Click);
            // 
            // tbResults
            // 
            this.tbResults.Location = new System.Drawing.Point(78, 199);
            this.tbResults.Multiline = true;
            this.tbResults.Name = "tbResults";
            this.tbResults.Size = new System.Drawing.Size(292, 52);
            this.tbResults.TabIndex = 6;
            // 
            // Lcount
            // 
            this.Lcount.AutoSize = true;
            this.Lcount.Location = new System.Drawing.Point(259, 281);
            this.Lcount.Name = "Lcount";
            this.Lcount.Size = new System.Drawing.Size(67, 13);
            this.Lcount.TabIndex = 7;
            this.Lcount.Text = "Телефонов:";
            // 
            // Delete
            // 
            this.Delete.Location = new System.Drawing.Point(194, 127);
            this.Delete.Name = "Delete";
            this.Delete.Size = new System.Drawing.Size(75, 23);
            this.Delete.TabIndex = 8;
            this.Delete.Text = "Удалить";
            this.Delete.UseVisualStyleBackColor = true;
            this.Delete.Click += new System.EventHandler(this.Delete_Click);
            // 
            // Update
            // 
            this.Update.Location = new System.Drawing.Point(194, 170);
            this.Update.Name = "Update";
            this.Update.Size = new System.Drawing.Size(75, 23);
            this.Update.TabIndex = 9;
            this.Update.Text = "Обновить";
            this.Update.UseVisualStyleBackColor = true;
            this.Update.Click += new System.EventHandler(this.Update_Click);
            // 
            // Results
            // 
            this.Results.Location = new System.Drawing.Point(89, 270);
            this.Results.Name = "Results";
            this.Results.Size = new System.Drawing.Size(89, 23);
            this.Results.TabIndex = 10;
            this.Results.Text = "Информация";
            this.Results.UseVisualStyleBackColor = true;
            this.Results.Click += new System.EventHandler(this.Results_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(438, 316);
            this.Controls.Add(this.Results);
            this.Controls.Add(this.Update);
            this.Controls.Add(this.Delete);
            this.Controls.Add(this.Lcount);
            this.Controls.Add(this.tbResults);
            this.Controls.Add(this.FirstNameButton);
            this.Controls.Add(this.NomerButton);
            this.Controls.Add(this.FirstName);
            this.Controls.Add(this.LPhone);
            this.Controls.Add(this.TBFirstName);
            this.Controls.Add(this.TBPhone);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox TBPhone;
        private System.Windows.Forms.TextBox TBFirstName;
        private System.Windows.Forms.Label LPhone;
        private System.Windows.Forms.Label FirstName;
        private System.Windows.Forms.Button NomerButton;
        private System.Windows.Forms.Button FirstNameButton;
        private System.Windows.Forms.TextBox tbResults;
        private System.Windows.Forms.Label Lcount;
        private System.Windows.Forms.Button Delete;
        private System.Windows.Forms.Button Update;
        private System.Windows.Forms.Button Results;
    }
}

