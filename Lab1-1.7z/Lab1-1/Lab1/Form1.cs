﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SQLite;

namespace Lab1
{
    public partial class Form1 : Form
    {
        private SQLiteConnection DB;

        public Form1()
        {
            InitializeComponent();
        }

        string GetPhonesCount()
        {
            SQLiteCommand CMD = DB.CreateCommand();
            CMD.CommandText = "select count (*) from Tele";
            return "Телефонов:" + CMD.ExecuteScalar().ToString();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            DB = new SQLiteConnection("Data source = E:\\DB");
            DB.Open();
            Lcount.Text = GetPhonesCount();

        }

        private void NomerButton_Click(object sender, EventArgs e)
        {
            if (TBFirstName.Text != "" && TBPhone.Text != "")
            {
                SQLiteCommand CMD = DB.CreateCommand();//возврат объекта класса
                CMD.CommandText = "insert into Tele (FirstName, Nomer) values(@FirstName, @phone)";
                CMD.Parameters.Add("@phone", System.Data.DbType.String).Value = TBPhone.Text.ToUpper();
                CMD.Parameters.Add("@FirstName", System.Data.DbType.String).Value = TBFirstName.Text.ToUpper();
                CMD.ExecuteNonQuery();
                Lcount.Text = GetPhonesCount();
                Form3 f = new Form3();//создание объекта типа Form
                if (f.ShowDialog() == DialogResult.OK) ;
                {
                    NomerButton.BackColor = Color.Green;
                }
            }

        }

        private void FirstNameButton_Click(object sender, EventArgs e)
        {
            tbResults.Clear();
            if (TBPhone.Text != "" || TBFirstName.Text != "")
            {
                SQLiteCommand CMD = DB.CreateCommand();
                CMD.CommandText = "select * from  Tele where FirstName like '%' || @FirstName || '%'  and Nomer like '%' || @phone || '%' ";
                CMD.Parameters.Add("@phone", System.Data.DbType.String).Value = TBPhone.Text.ToUpper();
                CMD.Parameters.Add("@FirstName", System.Data.DbType.String).Value = TBFirstName.Text.ToUpper();
                SQLiteDataReader SQL = CMD.ExecuteReader();
                if (SQL.HasRows)//возврат данных
                {
                    while (SQL.Read())
                    {
                        tbResults.Text += " Номер: " + SQL["Nomer"] + " FirstName: " + SQL["FirstName"] + "\r\n";
                    }
                }
                else tbResults.Text = "Not data";
                Form5 f = new Form5();//создание объекта типа Form
                if (f.ShowDialog() == DialogResult.OK) ;
                {
                    FirstNameButton.BackColor = Color.Green;
                }
            }
        }

        private void Delete_Click(object sender, EventArgs e)
        {
            tbResults.Clear();
            if (TBPhone.Text != "" || TBFirstName.Text != "")
            {
                SQLiteCommand CMD = DB.CreateCommand();//возврат объекта класса
                CMD.CommandText = "delete from Tele where FirstName = @FirstName and Nomer = @phone";
                CMD.Parameters.Add("@phone", System.Data.DbType.String).Value = TBPhone.Text.ToUpper();
                CMD.Parameters.Add("@FirstName", System.Data.DbType.String).Value = TBFirstName.Text.ToUpper();
                CMD.ExecuteNonQuery();
                Lcount.Text = GetPhonesCount();
                Form4 f = new Form4();//создание объекта типа Form
                if (f.ShowDialog() == DialogResult.OK) ;
                {
                    Delete.BackColor = Color.Red;
                }
            }

        }

        private void Update_Click(object sender, EventArgs e)
        {
            int id = 0;
            tbResults.Clear();
            if (TBPhone.Text != "" || TBFirstName.Text != "")
            {
                SQLiteCommand CMD = DB.CreateCommand();//возврат объекта класса
                CMD.CommandText = "select * from  Tele where FirstName like '%' || @FirstName || '%'  or Nomer like '%' || @phone || '%' ";
                CMD.Parameters.Add("@phone", System.Data.DbType.String).Value = TBPhone.Text.ToUpper();
                CMD.Parameters.Add("@FirstName", System.Data.DbType.String).Value = TBFirstName.Text.ToUpper();
                SQLiteDataReader SQL = CMD.ExecuteReader();
                Users user = new Users(0, "", "");
                if (SQL.HasRows)
                {
                    SQL.Read();

                    user.ID = int.Parse(SQL["id"].ToString());
                    user.FirstName = SQL["FirstName"].ToString();
                    user.Nomer = SQL["Nomer"].ToString();
                }

                SQLiteCommand CMD2 = DB.CreateCommand();
                CMD2.CommandText = "update Tele set FirstName = @FirstName, Nomer = @phone where id = @id";
                CMD2.Parameters.Add("@id", System.Data.DbType.Int32).Value = user.ID;
                CMD2.Parameters.Add("@phone", System.Data.DbType.String).Value = TBPhone.Text.ToUpper();
                CMD2.Parameters.Add("@FirstName", System.Data.DbType.String).Value = TBFirstName.Text.ToUpper();
                CMD2.ExecuteNonQuery();
                Lcount.Text = GetPhonesCount();
                Form6 f = new Form6();//создание объекта типа Form
                if (f.ShowDialog() == DialogResult.OK) ;
                {
                    Update.BackColor = Color.Green;
                }
            }
        }

        private void Results_Click(object sender, EventArgs e)
        {
            Form2 f = new Form2();//создание объекта типа Form2
            if (f.ShowDialog() == DialogResult.OK) ;
            {
                Results.BackColor = Color.Green;
            }
        }
    }
}
