﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab1
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        public bool auth(string login, string password)
        {
            if (login == "admin" && password == "admin")
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (auth(textBox1.Text, textBox2.Text))
            {
                Form newForm = new Form1();
                newForm.ShowDialog();
            }
            else
            {
                MessageBox.Show("Неверное имя пользователя");
            }
            textBox1.Clear();
            textBox2.Clear();
        }
        
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            

        }

        private void Login_Load(object sender, EventArgs e)
        {

        }
    }
}
