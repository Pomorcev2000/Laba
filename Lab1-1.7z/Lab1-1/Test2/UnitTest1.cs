﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Lab1;
using System.Windows.Forms;

namespace Test2
{
    [TestClass]
    public class UnitTest1
    {
        // тестирование создания экземпляра класса users
        [TestMethod]
        public void TestCreateUsers()
        {
            int id = 1;
            string fName = "Александр";
            string nom = "123";
            Users user = new Users(id, fName, nom);
            bool rez = true;
            if (user.ID != id || user.FirstName != fName || user.Nomer != nom)
            {
                rez = false;
            }
            Assert.IsTrue(rez, "Тест пройден");
        }
         //тестирование метода авторизации  
        [TestMethod]
        public void auth_isCorrect_returnTrue()
        {
            // Корректные данные
            string login = "admin";
            string pass = "admin";
            Login _login = new Login();
            //
            bool expected = true;

            //act
            bool result = _login.auth(login, pass);
            
            Assert.AreEqual(result, expected);
        }
    }
    }